Public Class login
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Call koneksiDB()
        Dim cek As String
        cek = "Select * From Karyawan Where ID_Karyawan= '" & UsernameTextBox.Text & "' and Password = '" & PasswordTextBox.Text & "'"
        CMD = New OleDb.OleDbCommand(cek, Conn)
        CMD.ExecuteNonQuery()
        DM = CMD.ExecuteReader
        If DM.HasRows = True Then
            DM.Read()
            'Input_Buku.Show()
            DataKaryawan.Show()
            Me.Hide()
        Else
            MsgBox(" Maaf Username atau Password Anda Salah ")
            Me.Show()
        End If
        DataKaryawan.Label13.Text = UsernameTextBox.Text
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

End Class

﻿Public Class Form1
    Sub KosongkanForm()
        txtkodebuku.Text = ""
        txtjudulbuku.Text = ""
        txthargabuku.Text = ""
        txtstokbuku.Text = ""
        txtWaktu.Text = ""
        txtkodebuku.Focus()
    End Sub
    Sub MatikanForm()
        txtkodebuku.Enabled = False
        txtjudulbuku.Enabled = False
        txthargabuku.Enabled = False
        txtstokbuku.Enabled = False
        cmjenisbuku.Enabled = False
        txtWaktu.Enabled = False
    End Sub
    Sub HidupkanForm()
        txtkodebuku.Enabled = True
        txtjudulbuku.Enabled = True
        txthargabuku.Enabled = True
        txtstokbuku.Enabled = True
        cmjenisbuku.Enabled = True
        txtWaktu.Enabled = True
    End Sub
    Sub TampilkanData()
        Call koneksiDB()
        DA = New OleDb.OleDbDataAdapter("select * from Kereta_Api ", Conn)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True
    End Sub

    Private Sub Input_Buku_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call MatikanForm()
        Call TampilkanData()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btninput.Click
        Call HidupkanForm()
        Call KosongkanForm()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        Call MatikanForm()
        Call KosongkanForm()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        If txtkodebuku.Text = "" Or txthargabuku.Text = "" Or txtjudulbuku.Text = "" Or txtstokbuku.Text = "" Or cmjenisbuku.Text = "" Or txtWaktu.Text = "" Then
            MsgBox("Data Buku Belum Lengkap")
            Exit Sub
        Else
            Call koneksiDB()
            CMD = New OleDb.OleDbCommand(" select * from Kereta_Api where Kode_Kereta ='" & txtkodebuku.Text & "'", Conn)
            DM = CMD.ExecuteReader
            DM.Read()
            If Not DM.HasRows Then
                Call koneksiDB()
                Dim simpan As String
                simpan = "insert into Kereta_Api values ('" & txtkodebuku.Text & "', '" & txtjudulbuku.Text & "', '" & txthargabuku.Text & "','" & txtstokbuku.Text & "','" & cmjenisbuku.Text & "','" & txtWaktu.Text & "')"
                CMD = New OleDb.OleDbCommand(simpan, Conn)
                CMD.ExecuteNonQuery()
                MsgBox("Input Data Sukses")
            Else
                MsgBox("Data Sudah Ada")
            End If
            Call MatikanForm()
            Call KosongkanForm()
            Call TampilkanData()
        End If
    End Sub

    Private Sub DGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellContentClick
        On Error Resume Next
        txtkodebuku.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        txtjudulbuku.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        txthargabuku.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        txtstokbuku.Text = DGV.Rows(e.RowIndex).Cells(3).Value
        cmjenisbuku.Text = DGV.Rows(e.RowIndex).Cells(4).Value
        txtWaktu.Text = DGV.Rows(e.RowIndex).Cells(5).Value
        Call HidupkanForm()
        txtkodebuku.Enabled = False
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        If txtkodebuku.Text = "" Or txthargabuku.Text = "" Or txtjudulbuku.Text = "" Or txtstokbuku.Text = "" Or cmjenisbuku.Text = "" Or txtWaktu.Text = "" Then
            MsgBox("Data Buku Belum Lengkap")
            Exit Sub
        Else
            Call koneksiDB()
            CMD = New OleDb.OleDbCommand(" update Kereta_Api set Nama_Kereta = '" & txtjudulbuku.Text & "', Stasiun_Awal ='" & txthargabuku.Text & "', Stasiun_Akhir = '" & txtstokbuku.Text & "', Kelas = '" & cmjenisbuku.Text & "', Waktu = '" & txtWaktu.Text & "' where Kode_Kereta ='" & txtkodebuku.Text & "'", Conn)
            DM = CMD.ExecuteReader
            MsgBox("Update Data Berhasil")
        End If
        Call KosongkanForm()
        Call MatikanForm()
        Call TampilkanData()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        If txtkodebuku.Text = "" Then
            MsgBox("Tidak ada data yang dipilih")
            Exit Sub
        Else
            If MessageBox.Show("Are you sure to delete this data ? ", "Konfirmasi", MessageBoxButtons.YesNoCancel) = Windows.Forms.DialogResult.Yes Then
                Call koneksiDB()
                CMD = New OleDb.OleDbCommand(" delete from Kereta_Api where Kode_Kereta ='" & txtkodebuku.Text & "'", Conn)
                DM = CMD.ExecuteReader
                MsgBox("Hapus Data Berhasil")
                Call MatikanForm()
                Call KosongkanForm()
                Call TampilkanData()
            Else
                Call KosongkanForm()
                Call TampilkanData()
            End If
        End If

    End Sub

    Private Sub txtWaktu_TextChanged(sender As Object, e As EventArgs) Handles txtWaktu.TextChanged

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If (txthargabuku.Text = "Halim" And txtstokbuku.Text = "Bekasi") Or (txthargabuku.Text = "Bekasi" And txtstokbuku.Text = "Halim") Then
            txtWaktu.Text = 10
        End If
        If (txthargabuku.Text = "Halim" And txtstokbuku.Text = "Karawang") Or (txthargabuku.Text = "Karawang" And txtstokbuku.Text = "Halim") Then
            txtWaktu.Text = 20
        End If
        If (txthargabuku.Text = "Halim" And txtstokbuku.Text = "Purwakarta") Or (txthargabuku.Text = "Purwakarta" And txtstokbuku.Text = "Halim") Then
            txtWaktu.Text = 30
        End If
        If (txthargabuku.Text = "Halim" And txtstokbuku.Text = "Bandung") Or (txthargabuku.Text = "Bandung" And txtstokbuku.Text = "Halim") Then
            txtWaktu.Text = 40
        End If
        If (txthargabuku.Text = "Bekasi" And txtstokbuku.Text = "Karawang") Or (txthargabuku.Text = "Karawang" And txtstokbuku.Text = "Bekasi") Then
            txtWaktu.Text = 10
        End If
        If (txthargabuku.Text = "Bekasi" And txtstokbuku.Text = "Purwakarta") Or (txthargabuku.Text = "Purwakarta" And txtstokbuku.Text = "Bekasi") Then
            txtWaktu.Text = 20
        End If
        If (txthargabuku.Text = "Bekasi" And txtstokbuku.Text = "Bandung") Or (txthargabuku.Text = "Bandung" And txtstokbuku.Text = "Bekasi") Then
            txtWaktu.Text = 30
        End If
        If (txthargabuku.Text = "Karawang" And txtstokbuku.Text = "Purwakarta") Or (txthargabuku.Text = "Purwakarta" And txtstokbuku.Text = "Karawang") Then
            txtWaktu.Text = 10
        End If
        If (txthargabuku.Text = "Karawang" And txtstokbuku.Text = "Bandung") Or (txthargabuku.Text = "Bandung" And txtstokbuku.Text = "Karawang") Then
            txtWaktu.Text = 20
        End If
        If (txthargabuku.Text = "Purwakarta" And txtstokbuku.Text = "Bandung") Or (txthargabuku.Text = "Bandung" And txtstokbuku.Text = "Purwakarta") Then
            txtWaktu.Text = 10
        End If
        If txthargabuku.Text = txtstokbuku.Text Then
            txtWaktu.Text = 0
        End If
    End Sub
End Class

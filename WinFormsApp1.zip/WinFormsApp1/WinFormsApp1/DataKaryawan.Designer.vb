﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DataKaryawan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtalamatkaryawan = New System.Windows.Forms.RichTextBox()
        Me.lststatuskaryawan = New System.Windows.Forms.ComboBox()
        Me.txttelpkaryawan = New System.Windows.Forms.TextBox()
        Me.txttempatlahirkaryawan = New System.Windows.Forms.TextBox()
        Me.txtnamakaryawan = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.txtidkaryawan = New System.Windows.Forms.TextBox()
        Me.lstagamakar = New System.Windows.Forms.ComboBox()
        Me.listjkkaryawan = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtnamaphotokaryawan = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.DGV2 = New System.Windows.Forms.DataGridView()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGV2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 35)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID Karyawan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 212)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Alamat"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 191)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "No Telpon"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 171)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Agama"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 151)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Jenis Kelamin"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 129)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Tanggal Lahir"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 108)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Tempat Lahir"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(13, 87)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Nama Karyawan"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(13, 257)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(39, 15)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Status"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(300, 195)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 15)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Foto Diri"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txtalamatkaryawan)
        Me.GroupBox1.Controls.Add(Me.lststatuskaryawan)
        Me.GroupBox1.Controls.Add(Me.txttelpkaryawan)
        Me.GroupBox1.Controls.Add(Me.txttempatlahirkaryawan)
        Me.GroupBox1.Controls.Add(Me.txtnamakaryawan)
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.txtidkaryawan)
        Me.GroupBox1.Controls.Add(Me.lstagamakar)
        Me.GroupBox1.Controls.Add(Me.listjkkaryawan)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(18, 25)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(266, 293)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data karyawan"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(134, 58)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(129, 23)
        Me.txtPassword.TabIndex = 21
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 60)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(57, 15)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Password"
        '
        'txtalamatkaryawan
        '
        Me.txtalamatkaryawan.Location = New System.Drawing.Point(134, 213)
        Me.txtalamatkaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtalamatkaryawan.Name = "txtalamatkaryawan"
        Me.txtalamatkaryawan.Size = New System.Drawing.Size(129, 41)
        Me.txtalamatkaryawan.TabIndex = 12
        Me.txtalamatkaryawan.Text = ""
        '
        'lststatuskaryawan
        '
        Me.lststatuskaryawan.FormattingEnabled = True
        Me.lststatuskaryawan.Items.AddRange(New Object() {"Manajer", "Supervisor", "Officer", "Admin"})
        Me.lststatuskaryawan.Location = New System.Drawing.Point(134, 255)
        Me.lststatuskaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.lststatuskaryawan.Name = "lststatuskaryawan"
        Me.lststatuskaryawan.Size = New System.Drawing.Size(129, 23)
        Me.lststatuskaryawan.TabIndex = 19
        '
        'txttelpkaryawan
        '
        Me.txttelpkaryawan.Location = New System.Drawing.Point(134, 191)
        Me.txttelpkaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txttelpkaryawan.Name = "txttelpkaryawan"
        Me.txttelpkaryawan.Size = New System.Drawing.Size(129, 23)
        Me.txttelpkaryawan.TabIndex = 18
        '
        'txttempatlahirkaryawan
        '
        Me.txttempatlahirkaryawan.Location = New System.Drawing.Point(134, 106)
        Me.txttempatlahirkaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txttempatlahirkaryawan.Name = "txttempatlahirkaryawan"
        Me.txttempatlahirkaryawan.Size = New System.Drawing.Size(129, 23)
        Me.txttempatlahirkaryawan.TabIndex = 17
        '
        'txtnamakaryawan
        '
        Me.txtnamakaryawan.Location = New System.Drawing.Point(134, 85)
        Me.txtnamakaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnamakaryawan.Name = "txtnamakaryawan"
        Me.txtnamakaryawan.Size = New System.Drawing.Size(129, 23)
        Me.txtnamakaryawan.TabIndex = 16
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(134, 129)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(2)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(129, 23)
        Me.DateTimePicker1.TabIndex = 13
        '
        'txtidkaryawan
        '
        Me.txtidkaryawan.Location = New System.Drawing.Point(134, 33)
        Me.txtidkaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtidkaryawan.Name = "txtidkaryawan"
        Me.txtidkaryawan.Size = New System.Drawing.Size(129, 23)
        Me.txtidkaryawan.TabIndex = 11
        '
        'lstagamakar
        '
        Me.lstagamakar.FormattingEnabled = True
        Me.lstagamakar.Items.AddRange(New Object() {"Islam", "Kristen", "Katolik", "Budha", "Hindu"})
        Me.lstagamakar.Location = New System.Drawing.Point(134, 171)
        Me.lstagamakar.Margin = New System.Windows.Forms.Padding(2)
        Me.lstagamakar.Name = "lstagamakar"
        Me.lstagamakar.Size = New System.Drawing.Size(129, 23)
        Me.lstagamakar.TabIndex = 15
        '
        'listjkkaryawan
        '
        Me.listjkkaryawan.FormattingEnabled = True
        Me.listjkkaryawan.Items.AddRange(New Object() {"Laki-laki", "Perempuan"})
        Me.listjkkaryawan.Location = New System.Drawing.Point(134, 149)
        Me.listjkkaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.listjkkaryawan.Name = "listjkkaryawan"
        Me.listjkkaryawan.Size = New System.Drawing.Size(129, 23)
        Me.listjkkaryawan.TabIndex = 14
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(473, 167)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(78, 20)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(300, 235)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(78, 20)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Simpan"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtnamaphotokaryawan
        '
        Me.txtnamaphotokaryawan.Location = New System.Drawing.Point(380, 195)
        Me.txtnamaphotokaryawan.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnamaphotokaryawan.Name = "txtnamaphotokaryawan"
        Me.txtnamaphotokaryawan.Size = New System.Drawing.Size(173, 23)
        Me.txtnamaphotokaryawan.TabIndex = 20
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(393, 235)
        Me.Button3.Margin = New System.Windows.Forms.Padding(2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(78, 20)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = "Delete"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(308, 25)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(231, 139)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'DGV2
        '
        Me.DGV2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV2.Location = New System.Drawing.Point(11, 340)
        Me.DGV2.Margin = New System.Windows.Forms.Padding(2)
        Me.DGV2.Name = "DGV2"
        Me.DGV2.RowHeadersWidth = 62
        Me.DGV2.RowTemplate.Height = 33
        Me.DGV2.Size = New System.Drawing.Size(522, 95)
        Me.DGV2.TabIndex = 23
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(106, 5)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 15)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Selamat Datang"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(201, 5)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 15)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Label13"
        '
        'DataKaryawan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(560, 474)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.DGV2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.txtnamaphotokaryawan)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label10)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "DataKaryawan"
        Me.Text = "DataKaryawan"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGV2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtalamatkaryawan As RichTextBox
    Friend WithEvents lststatuskaryawan As ComboBox
    Friend WithEvents txttelpkaryawan As TextBox
    Friend WithEvents txttempatlahirkaryawan As TextBox
    Friend WithEvents txtnamakaryawan As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents txtidkaryawan As TextBox
    Friend WithEvents lstagamakar As ComboBox
    Friend WithEvents listjkkaryawan As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents txtnamaphotokaryawan As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DGV2 As DataGridView
    Friend WithEvents Label11 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
End Class

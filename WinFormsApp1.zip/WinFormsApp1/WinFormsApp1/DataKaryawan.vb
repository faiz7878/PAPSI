﻿Public Class DataKaryawan
    Dim OpenFileDialog1 As New OpenFileDialog
    Sub KosongkanForm()
        txtidkaryawan.Text = ""
        txtalamatkaryawan.Text = ""
        txttempatlahirkaryawan.Text = ""
        listjkkaryawan.Text = ""
        lstagamakar.Text = ""
        txttelpkaryawan.Text = ""
        txtalamatkaryawan.Text = ""
        lststatuskaryawan.Text = ""
        txtnamakaryawan.Text = ""
        txtPassword.Text = ""
        txtidkaryawan.Focus()
    End Sub
    Sub MatikanForm()
        txtidkaryawan.Enabled = False
        txtalamatkaryawan.Enabled = False
        txttempatlahirkaryawan.Enabled = False
        listjkkaryawan.Enabled = False
        lstagamakar.Enabled = False
        txttelpkaryawan.Enabled = False
        txtalamatkaryawan.Enabled = False
        lststatuskaryawan.Enabled = False
        txtnamakaryawan.Enabled = False
        txtPassword.Enabled = False
    End Sub
    Sub HidupkanForm()
        txtidkaryawan.Enabled = True
        txtalamatkaryawan.Enabled = True
        txttempatlahirkaryawan.Enabled = True
        listjkkaryawan.Enabled = True
        lstagamakar.Enabled = True
        txttelpkaryawan.Enabled = True
        txtalamatkaryawan.Enabled = True
        lststatuskaryawan.Enabled = True
        txtnamakaryawan.Enabled = True
        txtPassword.Enabled = True
    End Sub
    Private Sub DGV2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV2.CellContentClick
        On Error Resume Next
        txtidkaryawan.Text = DGV2.Rows(e.RowIndex).Cells(0).Value
        txtPassword.Text = DGV2.Rows(e.RowIndex).Cells(1).Value
        txtnamakaryawan.Text = DGV2.Rows(e.RowIndex).Cells(2).Value
        txttempatlahirkaryawan.Text = DGV2.Rows(e.RowIndex).Cells(3).Value
        DateTimePicker1.Text = DGV2.Rows(e.RowIndex).Cells(4).Value
        listjkkaryawan.Text = DGV2.Rows(e.RowIndex).Cells(5).Value
        lstagamakar.Text = DGV2.Rows(e.RowIndex).Cells(6).Value
        txttelpkaryawan.Text = DGV2.Rows(e.RowIndex).Cells(7).Value
        txtalamatkaryawan.Text = DGV2.Rows(e.RowIndex).Cells(8).Value
        lststatuskaryawan.Text = DGV2.Rows(e.RowIndex).Cells(9).Value
        Call HidupkanForm()
        txtidkaryawan.Enabled = False
    End Sub
    Sub tampilkanData()
        DA = New OleDb.OleDbDataAdapter("SELECT * FROM karyawan", Conn)
        DS = New DataSet
        DA.Fill(DS)
        DGV2.DataSource = DS.Tables(0)
        DGV2.ReadOnly = True
    End Sub
    Private Sub DataKaryawan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilkanData()
    End Sub
    Sub foto1()
        PictureBox1.ImageLocation = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If txtidkaryawan.Text = "" Or txtnamakaryawan.Text = "" Or txttempatlahirkaryawan.Text = "" Or listjkkaryawan.Text = "" Or txttelpkaryawan.Text = "" Or txtalamatkaryawan.Text = "" Or lstagamakar.Text = "" Or lststatuskaryawan.Text = "" Or txtnamaphotokaryawan.Text = "" Then
            MsgBox("Data Karyawan Belum Lengkap")
            Exit Sub
        Else
            Call koneksiDB()
            CMD = New OleDb.OleDbCommand($" select * from Karyawan where ID_Karyawan ='{txtidkaryawan.Text}'", Conn)
            DM = CMD.ExecuteReader
            DM.Read()
            If Not DM.HasRows Then
                Dim simpan As String
                simpan = $"insert into Karyawan values ('{txtidkaryawan.Text}','{txtPassword.Text}','{txtnamakaryawan.Text}','{txttempatlahirkaryawan.Text}','{DateTimePicker1.Text}','{listjkkaryawan.Text}','{lstagamakar.Text}','{txttelpkaryawan.Text}','{txtalamatkaryawan.Text}', '{lststatuskaryawan.Text}','{txtnamaphotokaryawan.Text}')"
                CMD = New OleDb.OleDbCommand(simpan, Conn)
                CMD.ExecuteNonQuery()
                MsgBox("Input Data Sukses")
                PictureBox1.ImageLocation = ""
                tampilkanData()
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            OpenFileDialog1.Filter = " Image File (*.jpeg;*jpg;*.png;*.bmp;*.gif)| *.jpeg;*jpg;*.png;*.bmp;*.gif"
            If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                PictureBox1.Image = New Bitmap(OpenFileDialog1.FileName)
                txtnamaphotokaryawan.Text = OpenFileDialog1.FileName
            End If
        Catch ex As Exception
            Throw New ApplicationException("Gambar Gagal Masuk")
        End Try
    End Sub



    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If txtidkaryawan.Text = "" Then
            MsgBox("Tidak ada data yang dipilih")
            Exit Sub
        Else
            If MessageBox.Show("Are you sure to delete this data ? ", "Konfirmasi", MessageBoxButtons.YesNoCancel) = Windows.Forms.DialogResult.Yes Then
                Call koneksiDB()
                CMD = New OleDb.OleDbCommand(" delete from Karyawan where ID_Karyawan ='" & txtidkaryawan.Text & "'", Conn)
                DM = CMD.ExecuteReader
                MsgBox("Hapus Data Berhasil")
                Call MatikanForm()
                Call KosongkanForm()
                Call tampilkanData()
            Else
                Call KosongkanForm()
                Call tampilkanData()
            End If
        End If

    End Sub
End Class